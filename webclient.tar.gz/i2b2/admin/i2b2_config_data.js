{
	urlProxy: "index.php",
	urlFramework: "js-i2b2/",
	//-------------------------------------------------------------------------------------------
	// THESE ARE ALL THE DOMAINS A USER CAN LOGIN TO
	lstDomains: [
		{ name: "BRISSKIT",
		  domain: "BRISSKIT",
		  debug: true,
		  adminOnly: true,
		  urlCellPM: "http://localhost:9090/i2b2/services/PMService/"
		}
	]
	//-------------------------------------------------------------------------------------------
}
