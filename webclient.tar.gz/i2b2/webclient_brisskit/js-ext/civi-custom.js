var cohort = '';
var access = '1';

/*
$j('#pluginViewList-ExportXLS').click(function() {
	alert('1default.htm');
	var project = $j('#viewMode-Project').html();
	
	if (project == "Airways Disease DB - Consented")
	{
		alert('2default.htm');
		$j('#ExportXLS-OutputIncludeDemo_ZIP').hide();
		$j('#ExportXLS-ExportXLS-OutputIncludeDemo_BirthDate').hide();
		$j('#ExportXLS-ExportXLS-OutputIncludeDemo_BirthDate').hide();
		$j('#ExportXLS-ExportXLS-OutputIncludeDemo_BirthYear').hide();
		$j('#ExportXLS-ExportXLS-OutputIncludeDemo_BirthYear').hide();
		$j('#ExportXLS-ExportXLS-OutputIncludeDemo_Language').hide();		
	}
});
*/

function validateEmail(email) { 
    var re = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    return re.test(email);
}

function callbacki2b2(json)
{
        //alert( json.status );   
        //json.log
        cohort="";
        var patients = parseInt(json.patients)
        var missing = parseInt(json.missing)
        var trans = patients - missing;
        var status = json.status;
        var log = json.log;
               
        //$j( "#civiMode" ).hide();
        
        if (status == "success")
        {
        	//alert( trans + " out of " + patients + " patients transfered to civicrm");
        	access = '1';
        	
        	
        }
        
        if (status == "failure")
        {
        	//alert( log );
        	access = '0';
        }
}

function mvf1()
{
        var displayname = i2b2.ExportXLS.model.prsRecord.sdxInfo.sdxDisplayName;
        //alert( displayname ); // Gender@17:22:26 [4-8-2014] [demo] [PATIENTSET_412]
        var containsproject = displayname.split("[");
        var user = containsproject[2];
        user = user.substring(0,user.length-2);
        //alert( user ); // demo
        
        var project = $j('#viewMode-Project').html();
        //alert($j('#viewMode-Project').html());
        
        var email = document.getElementById('email').value;
        //alert(email);
        
        if (validateEmail(email)) {
        	
	        var civigroup = document.getElementById('civigroup').value;
	        
	        if (civigroup == '' || civigroup.length > 29)
	        {
	        	alert( "name of group cannot be empty or greater than 30 characters" );
	        }
	        else
	        {
		        //alert( civigroup ); 
		        
		        var n = project.length;
		        
		        // http://i2b216:8080/ADDtoI2B2/rest/service/i2b2callback1/
		
		    	if (cohort != "")
		    	{
		    		$j('#civi2').html('Creating cohort in civicrm (' + civigroup + ')');
		            
		    		i2b2.hive.CiviViewer.hide();
		    		
		            //$j( "#civiMode" ).show();
		            
			        $j.ajax({
			          dataType: 'jsonp',
			          jsonp: 'jsonp_callback',
			          url: 'http://' + window.location.hostname  + ':9090/ADDtoI2B2/rest/api/research/civi/i2b2callbackCIVI/'+cohort.substr(0,cohort.length-1)+'*'+project+'*'+user+'*'+civigroup+'*'+email,
			          success: function (json) {
			        	  $j('output').html(json);  
			        	  
			          }
			        });
			        
			        
		    	}
		    	else
		    	{   $j('output').html('error');
		    	    if (access == '0') { alert("You do not have the privilege to create cohorts"); }
		    	    else { alert("This cohort has no patients OR you may have already exported"); }
		    	    
		    	}
	        }
        
        }
        else
    	{
        	 alert("Email address is invalid. Please enter correct email address");
    	}
}

/*
$('#openBtn').click(function(){
	$('#myModal').modal({show:true})
});
*/
